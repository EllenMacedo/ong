package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static Connection conectar() {
        Connection conn = null;
        try {
            String url = "jdbc:postgresql://localhost:5432/ong";
            String user = "postgres"; // root, postgres etc.
            String password = "root";

            conn = DriverManager.getConnection(url, user, password);
            return conn;

        } catch (SQLException e) {
            System.out.println("Erro na conexão: " + e.getMessage());
            return null;
        }
    }
}
