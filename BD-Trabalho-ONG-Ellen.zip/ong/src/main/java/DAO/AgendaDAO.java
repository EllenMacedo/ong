package DAO;

import Conexao.Conexao;
import DTO.AgendaDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgendaDAO {

    public boolean inserirAgenda(AgendaDTO agenda) {
        String sql = "INSERT INTO agenda (id_usuario, titulo, descricao, data_inicio, data_fim, local) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, agenda.getIdUsuario());
            ps.setString(2, agenda.getTitulo());
            ps.setString(3, agenda.getDescricao());
            ps.setTimestamp(4, agenda.getDataInicio());
            ps.setTimestamp(5, agenda.getDataFim());
            ps.setString(6, agenda.getLocal());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarAgenda(AgendaDTO agenda) {
        String sql = "UPDATE agenda SET id_usuario=?, titulo=?, descricao=?, data_inicio=?, data_fim=?, local=? WHERE id_agenda=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, agenda.getIdUsuario());
            ps.setString(2, agenda.getTitulo());
            ps.setString(3, agenda.getDescricao());
            ps.setTimestamp(4, agenda.getDataInicio());
            ps.setTimestamp(5, agenda.getDataFim());
            ps.setString(6, agenda.getLocal());
            ps.setInt(7, agenda.getIdAgenda());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirAgenda(int idAgenda) {
        String sql = "DELETE FROM agenda WHERE id_agenda=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAgenda);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<AgendaDTO> listarAgenda() {
        List<AgendaDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM agenda ORDER BY data_inicio DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AgendaDTO agenda = new AgendaDTO();
                agenda.setIdAgenda(rs.getInt("id_agenda"));
                agenda.setIdUsuario(rs.getInt("id_usuario"));
                agenda.setTitulo(rs.getString("titulo"));
                agenda.setDescricao(rs.getString("descricao"));
                agenda.setDataInicio(rs.getTimestamp("data_inicio"));
                agenda.setDataFim(rs.getTimestamp("data_fim"));
                agenda.setLocal(rs.getString("local"));

                lista.add(agenda);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
