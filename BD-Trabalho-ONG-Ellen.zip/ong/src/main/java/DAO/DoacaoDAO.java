package DAO;

import DTO.DoacaoDTO;
import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoacaoDAO {

    public boolean inserirDoacao(DoacaoDTO doacao) {
        String sql = "INSERT INTO doacao (id_doador, tipo, valor, descricao, data) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (doacao.getIdDoador() != null) {
                ps.setInt(1, doacao.getIdDoador());
            } else {
                ps.setNull(1, Types.INTEGER);
            }
            ps.setString(2, doacao.getTipo());
            ps.setBigDecimal(3, doacao.getValor());
            ps.setString(4, doacao.getDescricao());
            ps.setDate(5, doacao.getData());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarDoacao(DoacaoDTO doacao) {
        String sql = "UPDATE doacao SET id_doador = ?, tipo = ?, valor = ?, descricao = ?, data = ? WHERE id_doacao = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (doacao.getIdDoador() != null) {
                ps.setInt(1, doacao.getIdDoador());
            } else {
                ps.setNull(1, Types.INTEGER);
            }
            ps.setString(2, doacao.getTipo());
            ps.setBigDecimal(3, doacao.getValor());
            ps.setString(4, doacao.getDescricao());
            ps.setDate(5, doacao.getData());
            ps.setInt(6, doacao.getIdDoacao());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirDoacao(int idDoacao) {
        String sql = "DELETE FROM doacao WHERE id_doacao = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idDoacao);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<DoacaoDTO> listarDoacoes() {
        List<DoacaoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM doacao ORDER BY data DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DoacaoDTO d = new DoacaoDTO();
                d.setIdDoacao(rs.getInt("id_doacao"));
                int idDoador = rs.getInt("id_doador");
                if (rs.wasNull()) d.setIdDoador(null);
                else d.setIdDoador(idDoador);

                d.setTipo(rs.getString("tipo"));
                d.setValor(rs.getBigDecimal("valor"));
                d.setDescricao(rs.getString("descricao"));
                d.setData(rs.getDate("data"));

                lista.add(d);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public DoacaoDTO buscarDoacaoPorId(int idDoacao) {
        DoacaoDTO doacao = null;
        String sql = "SELECT * FROM doacao WHERE id_doacao = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idDoacao);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    doacao = new DoacaoDTO();
                    doacao.setIdDoacao(rs.getInt("id_doacao"));

                    int idDoador = rs.getInt("id_doador");
                    if (rs.wasNull()) doacao.setIdDoador(null);
                    else doacao.setIdDoador(idDoador);

                    doacao.setTipo(rs.getString("tipo"));
                    doacao.setValor(rs.getBigDecimal("valor"));
                    doacao.setDescricao(rs.getString("descricao"));
                    doacao.setData(rs.getDate("data"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doacao;
    }
    
    public List<DoacaoDTO> listarDoacoesPorDoador(int idDoador) {
    List<DoacaoDTO> lista = new ArrayList<>();
    String sql = "SELECT * FROM doacao WHERE id_doador = ? ORDER BY data DESC";

    try (Connection con = Conexao.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, idDoador);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            DoacaoDTO d = new DoacaoDTO();
            d.setIdDoacao(rs.getInt("id_doacao"));

            int idDoadorBanco = rs.getInt("id_doador");
            d.setIdDoador(rs.wasNull() ? null : idDoadorBanco);

            d.setTipo(rs.getString("tipo"));
            d.setValor(rs.getBigDecimal("valor"));
            d.setDescricao(rs.getString("descricao"));
            d.setData(rs.getDate("data"));

            lista.add(d);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
}

}
