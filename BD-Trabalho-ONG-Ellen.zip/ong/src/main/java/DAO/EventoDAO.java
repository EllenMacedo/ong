package DAO;

import DTO.EventoDTO;
import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {

    public boolean inserirEvento(EventoDTO evento) {
        String sql = "INSERT INTO evento (nome, descricao, data_inicio, data_fim, local, id_responsavel) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, evento.getNome());
            ps.setString(2, evento.getDescricao());
            ps.setTimestamp(3, evento.getDataInicio());
            ps.setTimestamp(4, evento.getDataFim());
            ps.setString(5, evento.getLocal());
            if (evento.getIdResponsavel() != null) {
                ps.setInt(6, evento.getIdResponsavel());
            } else {
                ps.setNull(6, Types.INTEGER);
            }
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarEvento(EventoDTO evento) {
        String sql = "UPDATE evento SET nome = ?, descricao = ?, data_inicio = ?, data_fim = ?, local = ?, id_responsavel = ? WHERE id_evento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, evento.getNome());
            ps.setString(2, evento.getDescricao());
            ps.setTimestamp(3, evento.getDataInicio());
            ps.setTimestamp(4, evento.getDataFim());
            ps.setString(5, evento.getLocal());
            if (evento.getIdResponsavel() != null) {
                ps.setInt(6, evento.getIdResponsavel());
            } else {
                ps.setNull(6, Types.INTEGER);
            }
            ps.setInt(7, evento.getIdEvento());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirEvento(int idEvento) {
        String sql = "DELETE FROM evento WHERE id_evento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEvento);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<EventoDTO> listarEventos() {
        List<EventoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM evento ORDER BY data_inicio";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                EventoDTO e = new EventoDTO();
                e.setIdEvento(rs.getInt("id_evento"));
                e.setNome(rs.getString("nome"));
                e.setDescricao(rs.getString("descricao"));
                e.setDataInicio(rs.getTimestamp("data_inicio"));
                e.setDataFim(rs.getTimestamp("data_fim"));
                e.setLocal(rs.getString("local"));
                int idResp = rs.getInt("id_responsavel");
                if (rs.wasNull()) {
                    e.setIdResponsavel(null);
                } else {
                    e.setIdResponsavel(idResp);
                }
                lista.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }

    public EventoDTO buscarEventoPorId(int idEvento) {
        EventoDTO evento = null;
        String sql = "SELECT * FROM evento WHERE id_evento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEvento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    evento = new EventoDTO();
                    evento.setIdEvento(rs.getInt("id_evento"));
                    evento.setNome(rs.getString("nome"));
                    evento.setDescricao(rs.getString("descricao"));
                    evento.setDataInicio(rs.getTimestamp("data_inicio"));
                    evento.setDataFim(rs.getTimestamp("data_fim"));
                    evento.setLocal(rs.getString("local"));
                    int idResp = rs.getInt("id_responsavel");
                    if (rs.wasNull()) {
                        evento.setIdResponsavel(null);
                    } else {
                        evento.setIdResponsavel(idResp);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evento;
    }
}
