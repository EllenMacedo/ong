package DAO;

import Conexao.Conexao;
import DTO.FinanceiroDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FinanceiroDAO {

    public boolean inserirLancamento(FinanceiroDTO lancamento) {
        String sql = "INSERT INTO financeiro (tipo, valor, descricao, data, projeto_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lancamento.getTipo());
            ps.setBigDecimal(2, lancamento.getValor());
            ps.setString(3, lancamento.getDescricao());
            ps.setDate(4, lancamento.getData());

            if (lancamento.getIdProjeto() != null) {
                ps.setInt(5, lancamento.getIdProjeto());
            } else {
                ps.setNull(5, Types.INTEGER);
            }
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarLancamento(FinanceiroDTO lancamento) {
        String sql = "UPDATE financeiro SET tipo = ?, valor = ?, descricao = ?, data = ?, projeto_id = ? WHERE id_lancamento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lancamento.getTipo());
            ps.setBigDecimal(2, lancamento.getValor());
            ps.setString(3, lancamento.getDescricao());
            ps.setDate(4, lancamento.getData());

            if (lancamento.getIdProjeto() != null) {
                ps.setInt(5, lancamento.getIdProjeto());
            } else {
                ps.setNull(5, Types.INTEGER);
            }

            ps.setInt(6, lancamento.getIdLancamento());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirLancamento(int idLancamento) {
        String sql = "DELETE FROM financeiro WHERE id_lancamento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idLancamento);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<FinanceiroDTO> listarLancamentos() {
        List<FinanceiroDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM financeiro ORDER BY data DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                FinanceiroDTO f = new FinanceiroDTO();
                f.setIdLancamento(rs.getInt("id_lancamento"));
                f.setTipo(rs.getString("tipo"));
                f.setValor(rs.getBigDecimal("valor"));
                f.setDescricao(rs.getString("descricao"));
                f.setData(rs.getDate("data"));
                int idProjeto = rs.getInt("projeto_id");
                if (rs.wasNull()) f.setIdProjeto(null);
                else f.setIdProjeto(idProjeto);

                lista.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public FinanceiroDTO buscarPorId(int idLancamento) {
        FinanceiroDTO f = null;
        String sql = "SELECT * FROM financeiro WHERE id_lancamento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idLancamento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    f = new FinanceiroDTO();
                    f.setIdLancamento(rs.getInt("id_lancamento"));
                    f.setTipo(rs.getString("tipo"));
                    f.setValor(rs.getBigDecimal("valor"));
                    f.setDescricao(rs.getString("descricao"));
                    f.setData(rs.getDate("data"));
                    int idProjeto = rs.getInt("projeto_id");
                    if (rs.wasNull()) f.setIdProjeto(null);
                    else f.setIdProjeto(idProjeto);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return f;
    }
}
