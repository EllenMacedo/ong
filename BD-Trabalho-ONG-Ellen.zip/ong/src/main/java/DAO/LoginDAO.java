package DAO;

import Conexao.Conexao;
import DTO.LoginDTO;

import java.sql.*;
import javax.swing.JOptionPane;

public class LoginDAO {

    // Verifica usuário e retorna ResultSet se encontrado
    public ResultSet autenticarUsuario(LoginDTO login) {
        Connection conn = Conexao.conectar();
        try {
            String sql = "SELECT * FROM usuario WHERE email = ? AND senha = ? AND ativo = TRUE";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, login.getEmail());
            pstm.setString(2, login.getSenha()); // Atenção: usar hash depois
            return pstm.executeQuery();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "LoginDAO: " + e.getMessage());
            return null;
        }
    }

    // Atualiza campo ultimo_login com timestamp atual
    public boolean atualizarUltimoLogin(int idUsuario) {
        Connection conn = Conexao.conectar();
        try {
            String sql = "UPDATE usuario SET ultimo_login = CURRENT_TIMESTAMP WHERE id_usuario = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idUsuario);
            int affectedRows = pstm.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar último login: " + e.getMessage());
            return false;
        }
    }
}
