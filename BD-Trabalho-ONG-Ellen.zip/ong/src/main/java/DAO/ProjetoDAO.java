package DAO;

import DTO.ProjetoDTO;
import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {

    // Inserir projeto
    public boolean inserirProjeto(ProjetoDTO projeto) {
        String sql = "INSERT INTO projeto (nome, objetivo, status, data_inicio, data_fim) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, projeto.getNome());
            ps.setString(2, projeto.getObjetivo());
            ps.setString(3, projeto.getStatus());
            ps.setDate(4, projeto.getDataInicio());
            ps.setDate(5, projeto.getDataFim());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Atualizar projeto
    public boolean atualizarProjeto(ProjetoDTO projeto) {
        String sql = "UPDATE projeto SET nome = ?, objetivo = ?, status = ?, data_inicio = ?, data_fim = ? WHERE id_projeto = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, projeto.getNome());
            ps.setString(2, projeto.getObjetivo());
            ps.setString(3, projeto.getStatus());
            ps.setDate(4, projeto.getDataInicio());
            ps.setDate(5, projeto.getDataFim());
            ps.setInt(6, projeto.getIdProjeto());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Excluir projeto
    public boolean excluirProjeto(int idProjeto) {
        String sql = "DELETE FROM projeto WHERE id_projeto = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idProjeto);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar todos os projetos
    public List<ProjetoDTO> listarProjetos() {
        List<ProjetoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM projeto ORDER BY id_projeto";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ProjetoDTO p = new ProjetoDTO();
                p.setIdProjeto(rs.getInt("id_projeto"));
                p.setNome(rs.getString("nome"));
                p.setObjetivo(rs.getString("objetivo"));
                p.setStatus(rs.getString("status"));
                p.setDataInicio(rs.getDate("data_inicio"));
                p.setDataFim(rs.getDate("data_fim"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Buscar projeto por id
    public ProjetoDTO buscarProjetoPorId(int idProjeto) {
        ProjetoDTO projeto = null;
        String sql = "SELECT * FROM projeto WHERE id_projeto = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idProjeto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    projeto = new ProjetoDTO();
                    projeto.setIdProjeto(rs.getInt("id_projeto"));
                    projeto.setNome(rs.getString("nome"));
                    projeto.setObjetivo(rs.getString("objetivo"));
                    projeto.setStatus(rs.getString("status"));
                    projeto.setDataInicio(rs.getDate("data_inicio"));
                    projeto.setDataFim(rs.getDate("data_fim"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return projeto;
    }
}
