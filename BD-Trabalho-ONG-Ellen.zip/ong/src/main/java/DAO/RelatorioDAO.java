package DAO;

import Conexao.Conexao;
import DTO.RelatorioDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RelatorioDAO {

    public boolean inserirRelatorio(RelatorioDTO r) {
        String sql = "INSERT INTO relatorio (titulo, descricao, data_criacao, id_projeto, id_usuario) VALUES (?, ?, CURRENT_TIMESTAMP, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, r.getTitulo());
            ps.setString(2, r.getDescricao());

            if (r.getIdProjeto() != null) {
                ps.setInt(3, r.getIdProjeto());
            } else {
                ps.setNull(3, Types.INTEGER);
            }

            if (r.getIdUsuario() != null) {
                ps.setInt(4, r.getIdUsuario());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarRelatorio(RelatorioDTO r) {
        String sql = "UPDATE relatorio SET titulo = ?, descricao = ?, id_projeto = ?, id_usuario = ? WHERE id_relatorio = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, r.getTitulo());
            ps.setString(2, r.getDescricao());

            if (r.getIdProjeto() != null) {
                ps.setInt(3, r.getIdProjeto());
            } else {
                ps.setNull(3, Types.INTEGER);
            }

            if (r.getIdUsuario() != null) {
                ps.setInt(4, r.getIdUsuario());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            ps.setInt(5, r.getIdRelatorio());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirRelatorio(int idRelatorio) {
        String sql = "DELETE FROM relatorio WHERE id_relatorio = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idRelatorio);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<RelatorioDTO> listarRelatorios() {
        List<RelatorioDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM relatorio ORDER BY data_criacao DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                RelatorioDTO r = new RelatorioDTO();
                r.setIdRelatorio(rs.getInt("id_relatorio"));
                r.setTitulo(rs.getString("titulo"));
                r.setDescricao(rs.getString("descricao"));
                r.setDataCriacao(rs.getTimestamp("data_criacao"));

                int idProjeto = rs.getInt("id_projeto");
                if (rs.wasNull()) r.setIdProjeto(null);
                else r.setIdProjeto(idProjeto);

                int idUsuario = rs.getInt("id_usuario");
                if (rs.wasNull()) r.setIdUsuario(null);
                else r.setIdUsuario(idUsuario);

                lista.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public RelatorioDTO buscarPorId(int idRelatorio) {
        RelatorioDTO r = null;
        String sql = "SELECT * FROM relatorio WHERE id_relatorio = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idRelatorio);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    r = new RelatorioDTO();
                    r.setIdRelatorio(rs.getInt("id_relatorio"));
                    r.setTitulo(rs.getString("titulo"));
                    r.setDescricao(rs.getString("descricao"));
                    r.setDataCriacao(rs.getTimestamp("data_criacao"));

                    int idProjeto = rs.getInt("id_projeto");
                    if (rs.wasNull()) r.setIdProjeto(null);
                    else r.setIdProjeto(idProjeto);

                    int idUsuario = rs.getInt("id_usuario");
                    if (rs.wasNull()) r.setIdUsuario(null);
                    else r.setIdUsuario(idUsuario);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }
}
