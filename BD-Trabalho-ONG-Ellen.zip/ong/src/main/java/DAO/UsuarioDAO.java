package DAO;

import DTO.UsuarioDTO;
import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public List<UsuarioDTO> listarUsuarios() {
        List<UsuarioDTO> lista = new ArrayList<>();
        String sql = "SELECT id_usuario, nome, email, perfil, ativo, id_endereco FROM usuario ORDER BY nome";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                UsuarioDTO u = new UsuarioDTO();
                u.setIdUsuario(rs.getInt("id_usuario"));
                u.setNome(rs.getString("nome"));
                u.setEmail(rs.getString("email"));
                u.setPerfil(rs.getString("perfil"));
                u.setAtivo(rs.getBoolean("ativo"));
                int idEndereco = rs.getInt("id_endereco");
                u.setIdEndereco(rs.wasNull() ? null : idEndereco);
                lista.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean inserirUsuario(UsuarioDTO u) {
        String sql = "INSERT INTO usuario (nome, email, senha, perfil, ativo, id_endereco) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getSenha()); // Deve vir já criptografada
            ps.setString(4, u.getPerfil());
            ps.setBoolean(5, u.isAtivo());
            if (u.getIdEndereco() != null) {
                ps.setInt(6, u.getIdEndereco());
            } else {
                ps.setNull(6, Types.INTEGER);
            }
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarUsuario(UsuarioDTO u) {
        String sql = "UPDATE usuario SET nome=?, email=?, perfil=?, ativo=?, id_endereco=? WHERE id_usuario=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getPerfil());
            ps.setBoolean(4, u.isAtivo());
            if (u.getIdEndereco() != null) {
                ps.setInt(5, u.getIdEndereco());
            } else {
                ps.setNull(5, Types.INTEGER);
            }
            ps.setInt(6, u.getIdUsuario());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean desativarAtivarUsuario(int idUsuario, boolean ativo) {
        String sql = "UPDATE usuario SET ativo=? WHERE id_usuario=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, ativo);
            ps.setInt(2, idUsuario);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirUsuario(int idUsuario) {
        String sql = "DELETE FROM usuario WHERE id_usuario=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public UsuarioDTO buscarUsuarioPorId(int idUsuario) {
        String sql = "SELECT * FROM usuario WHERE id_usuario=?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    UsuarioDTO u = new UsuarioDTO();
                    u.setIdUsuario(rs.getInt("id_usuario"));
                    u.setNome(rs.getString("nome"));
                    u.setEmail(rs.getString("email"));
                    u.setPerfil(rs.getString("perfil"));
                    u.setAtivo(rs.getBoolean("ativo"));
                    int idEndereco = rs.getInt("id_endereco");
                    u.setIdEndereco(rs.wasNull() ? null : idEndereco);
                    u.setSenha(rs.getString("senha")); // cuidado: só se for pra editar
                    return u;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
}
