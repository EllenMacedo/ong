package DTO;

import java.math.BigDecimal;
import java.sql.Date;

public class DoacaoDTO {
    private int idDoacao;
    private Integer idDoador; // pode ser null
    private String tipo; // 'financeira' ou 'material'
    private BigDecimal valor;
    private String descricao;
    private Date data;

    public int getIdDoacao() {
        return idDoacao;
    }
    public void setIdDoacao(int idDoacao) {
        this.idDoacao = idDoacao;
    }
    public Integer getIdDoador() {
        return idDoador;
    }
    public void setIdDoador(Integer idDoador) {
        this.idDoador = idDoador;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public BigDecimal getValor() {
        return valor;
    }
    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public Date getData() {
        return data;
    }
    public void setData(Date data) {
        this.data = data;
    }
}
