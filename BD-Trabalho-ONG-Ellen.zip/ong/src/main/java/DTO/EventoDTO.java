package DTO;

import java.sql.Timestamp;

public class EventoDTO {
    private int idEvento;
    private String nome;
    private String descricao;
    private Timestamp dataInicio;
    private Timestamp dataFim;
    private String local;
    private Integer idResponsavel; // Pode ser null

    // Getters e setters
    public int getIdEvento() {
        return idEvento;
    }
    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public Timestamp getDataInicio() {
        return dataInicio;
    }
    public void setDataInicio(Timestamp dataInicio) {
        this.dataInicio = dataInicio;
    }
    public Timestamp getDataFim() {
        return dataFim;
    }
    public void setDataFim(Timestamp dataFim) {
        this.dataFim = dataFim;
    }
    public String getLocal() {
        return local;
    }
    public void setLocal(String local) {
        this.local = local;
    }
    public Integer getIdResponsavel() {
        return idResponsavel;
    }
    public void setIdResponsavel(Integer idResponsavel) {
        this.idResponsavel = idResponsavel;
    }
}
