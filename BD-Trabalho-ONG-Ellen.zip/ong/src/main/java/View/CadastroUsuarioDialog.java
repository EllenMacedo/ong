package View;

import DAO.UsuarioDAO;
import DTO.UsuarioDTO;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class CadastroUsuarioDialog extends JDialog {

    private JTextField txtNome, txtEmail;
    private JPasswordField txtSenha;
    private JComboBox<String> cbPerfil;
    private JCheckBox chkAtivo;
    private JButton btnSalvar, btnCancelar;

    private Integer idUsuario; // null = novo usuário
    private UsuarioDAO usuarioDAO;

    public CadastroUsuarioDialog(Frame parent, boolean modal, Integer idUsuario) {
        super(parent, modal);
        this.idUsuario = idUsuario;
        usuarioDAO = new UsuarioDAO();

        configurarTela();
        if (idUsuario != null) carregarDados();
    }

    private void configurarTela() {
        setTitle(idUsuario == null ? "Cadastrar Usuário" : "Editar Usuário");
        setSize(450, 320);
        setLocationRelativeTo(getParent());

        // Fundo azul claro
        getContentPane().setBackground(new Color(173, 216, 230));

        // Layout GridBagLayout para melhor controle
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12); // margem interna
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Linha 0 - Nome
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        add(new JLabel("Nome:"), gbc);

        txtNome = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        add(txtNome, gbc);

        // Linha 1 - Email
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        add(new JLabel("Email:"), gbc);

        txtEmail = new JTextField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        add(txtEmail, gbc);

        // Linha 2 - Senha
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        add(new JLabel("Senha:"), gbc);

        txtSenha = new JPasswordField();
        gbc.gridx = 1;
        gbc.weightx = 1;
        add(txtSenha, gbc);

        // Linha 3 - Perfil
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        add(new JLabel("Perfil:"), gbc);

        cbPerfil = new JComboBox<>(new String[]{"admin", "voluntario", "beneficiario", "doador"});
        gbc.gridx = 1;
        gbc.weightx = 1;
        add(cbPerfil, gbc);

        // Linha 4 - Ativo
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
        add(new JLabel("Ativo:"), gbc);

        chkAtivo = new JCheckBox();
        chkAtivo.setSelected(true);
        gbc.gridx = 1;
        gbc.weightx = 1;
        add(chkAtivo, gbc);

        // Linha 5 - Botões (Salvar e Cancelar)
        JPanel painelBotoes = new JPanel();
        painelBotoes.setBackground(new Color(173, 216, 230));
        btnSalvar = new JButton("Salvar");
        btnCancelar = new JButton("Cancelar");

        btnSalvar.addActionListener(e -> salvarUsuario());
        btnCancelar.addActionListener(e -> dispose());

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnCancelar);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 0;
        add(painelBotoes, gbc);
    }

    private void carregarDados() {
        UsuarioDTO u = usuarioDAO.buscarUsuarioPorId(idUsuario);
        if (u != null) {
            txtNome.setText(u.getNome());
            txtEmail.setText(u.getEmail());
            // senha não é carregada por segurança
            cbPerfil.setSelectedItem(u.getPerfil());
            chkAtivo.setSelected(u.isAtivo());
        }
    }

    private void salvarUsuario() {
        String nome = txtNome.getText().trim();
        String email = txtEmail.getText().trim();
        char[] senhaChars = txtSenha.getPassword();
        String senha = new String(senhaChars).trim();
        String perfil = (String) cbPerfil.getSelectedItem();
        boolean ativo = chkAtivo.isSelected();

        if (nome.isEmpty() || email.isEmpty() || (idUsuario == null && senha.isEmpty())) {
            JOptionPane.showMessageDialog(this, "Preencha os campos obrigatórios (senha para novo usuário).");
            return;
        }

        UsuarioDTO u = new UsuarioDTO();
        u.setNome(nome);
        u.setEmail(email);
        u.setPerfil(perfil);
        u.setAtivo(ativo);

        if (!senha.isEmpty()) {
            u.setSenha(senha); // ideal: aplicar hash aqui
        } else if (idUsuario != null) {
            u.setSenha(null); // senha não será alterada
        }

        if (idUsuario != null) {
            u.setIdUsuario(idUsuario);
            boolean ok = usuarioDAO.atualizarUsuario(u);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Usuário atualizado com sucesso!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar usuário.");
            }
        } else {
            boolean ok = usuarioDAO.inserirUsuario(u);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar usuário.");
            }
        }
        Arrays.fill(senhaChars, '0'); // limpa senha da memória
    }
}
