package View;

import javax.swing.*;

public class CampanhasDisponiveisView extends JFrame {

    public CampanhasDisponiveisView() {
        setTitle("Campanhas Disponíveis");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl = new JLabel("Campanhas Atuais para Apoio:");
        lbl.setBounds(30, 20, 300, 30);
        add(lbl);

        JTextArea txtCampanhas = new JTextArea();
        txtCampanhas.setEditable(false);
        txtCampanhas.setText("• Campanha 1 - Ajude com materiais escolares\n• Campanha 2 - Apoie alimentação\n...");
        JScrollPane scroll = new JScrollPane(txtCampanhas);
        scroll.setBounds(30, 60, 320, 120);
        add(scroll);

        JButton btnApoiar = new JButton("Apoiar Campanha");
        btnApoiar.setBounds(30, 200, 150, 30);
        add(btnApoiar);

        btnApoiar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Obrigado por seu apoio!");
        });
    }
}
