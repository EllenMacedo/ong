package View;

import javax.swing.*;
import java.awt.*;

public class DoadorView extends JFrame {

    public DoadorView() {
        setTitle("Área do Doador");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Tela cheia
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 245, 220)); // Bege claro
        setLayout(new BorderLayout());
        

        // Barra lateral verde claro com botões pequenos
        JPanel barraLateral = new JPanel();
        barraLateral.setBackground(new Color(144, 238, 144)); // Verde claro
        barraLateral.setPreferredSize(new Dimension(200, getHeight()));
        barraLateral.setLayout(new BoxLayout(barraLateral, BoxLayout.Y_AXIS));

        JButton btnDoacoes = new JButton("Minhas Doações");
        JButton btnEventos = new JButton("Lista de Eventos");
        JButton btnLogout = new JButton("Logout");

        Dimension tamanhoBotao = new Dimension(180, 30);
        btnDoacoes.setMaximumSize(tamanhoBotao);
        btnDoacoes.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEventos.setMaximumSize(tamanhoBotao);
        btnEventos.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogout.setMaximumSize(tamanhoBotao);
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);

        barraLateral.add(Box.createVerticalStrut(30));
        barraLateral.add(btnDoacoes);
        barraLateral.add(Box.createVerticalStrut(15));
        barraLateral.add(btnEventos);
        barraLateral.add(Box.createVerticalGlue());
        barraLateral.add(btnLogout);
        barraLateral.add(Box.createVerticalStrut(20));

        // Painel central branco com bordas arredondadas
        JPanel painelCentral = new JPanel();
        painelCentral.setBackground(Color.WHITE);
        painelCentral.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        painelCentral.setLayout(null);
        painelCentral.setPreferredSize(new Dimension(800, 600));

        JLabel lbl = new JLabel("Bem-vindo, Doador!");
        lbl.setBounds(300, 50, 300, 30);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        painelCentral.add(lbl);

        // Container para centralizar o painel central
        JPanel containerCentral = new JPanel(new GridBagLayout());
        containerCentral.setBackground(new Color(245, 245, 220)); // Bege claro
        containerCentral.add(painelCentral);

        add(barraLateral, BorderLayout.WEST);
        add(containerCentral, BorderLayout.CENTER);

        // Ações dos botões
        btnLogout.addActionListener(e -> {
            dispose();
            new EntradaView().setVisible(true);
        });

        btnDoacoes.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Abrir tela de doações...");
            new DoacaoView().setVisible(true);
        });

        btnEventos.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Abrir tela de eventos...");
            new EventoView().setVisible(true);
        });
    }
}
