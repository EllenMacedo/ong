package View;

import javax.swing.*;

public class DocumentosBeneficiarioView extends JFrame {

    public DocumentosBeneficiarioView() {
        setTitle("Seus Documentos");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl = new JLabel("Documentos Recebidos:");
        lbl.setBounds(30, 20, 300, 30);
        add(lbl);

        JTextArea txtDocs = new JTextArea();
        txtDocs.setEditable(false);
        txtDocs.setText("• Comprovante de inscrição\n• Termo de participação\n...");
        JScrollPane scroll = new JScrollPane(txtDocs);
        scroll.setBounds(30, 60, 320, 120);
        add(scroll);
    }
}
