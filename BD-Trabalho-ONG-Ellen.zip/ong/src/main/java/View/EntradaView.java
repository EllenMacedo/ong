package View;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class EntradaView extends JFrame {

    private JButton btnLogin;
    private JButton btnCadastrar;

    public EntradaView() {
        // Tela cheia
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(false); // se quiser sem bordas da janela, use true
        setTitle("Bem-vindo");

        // Painel principal com fundo bege claro
        JPanel painelPrincipal = new JPanel(new BorderLayout());
        painelPrincipal.setBackground(new Color(245, 245, 220)); // bege claro

        // Painel lateral (menu ou logo)
        JPanel painelLateral = new JPanel();
        painelLateral.setPreferredSize(new Dimension(250, getHeight()));
        painelLateral.setBackground(new Color(144, 238, 144)); // verde claro
        painelLateral.setLayout(new BorderLayout());

        JLabel lblLogo = new JLabel("ONG", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Arial", Font.BOLD, 20));
        lblLogo.setForeground(Color.DARK_GRAY);
        painelLateral.add(lblLogo, BorderLayout.NORTH);

        // Painel de conteúdo (com bordas arredondadas)
        JPanel painelConteudo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30));
            }
        };
        painelConteudo.setOpaque(false);
        painelConteudo.setLayout(null);
        painelConteudo.setPreferredSize(new Dimension(400, 300));

        JLabel lblBemVindo = new JLabel("Bem-vindo ao sistema!");
        lblBemVindo.setBounds(100, 20, 200, 25);
        painelConteudo.add(lblBemVindo);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(100, 60, 200, 30);
        painelConteudo.add(btnLogin);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(100, 110, 200, 30);
        painelConteudo.add(btnCadastrar);

        // Painel de centro com o painelConteudo centralizado
        JPanel painelCentral = new JPanel(new GridBagLayout());
        painelCentral.setOpaque(false);
        painelCentral.add(painelConteudo);

        painelPrincipal.add(painelLateral, BorderLayout.WEST);
        painelPrincipal.add(painelCentral, BorderLayout.CENTER);

        add(painelPrincipal);
        setVisible(true);

        // Ações
        btnLogin.addActionListener(e -> {
            new LoginView().setVisible(true);
            dispose();
        });

        btnCadastrar.addActionListener(e -> {
            new CadastroView().setVisible(true);
            dispose();
        });
    }
}
