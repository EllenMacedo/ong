package View;

import DAO.EventoDAO;
import DTO.EventoDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class EventoView extends JFrame {

    private JTextField txtId;
    private JTextField txtNome;
    private JTextArea txtDescricao;
    private JTextField txtDataInicio;
    private JTextField txtDataFim;
    private JTextField txtLocal;
    private JTextField txtIdResponsavel;

    private JTable tabela;
    private DefaultTableModel modelo;

    private EventoDAO eventoDAO;

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public EventoView() {
        eventoDAO = new EventoDAO();
        initComponents();
        listarEventos();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Eventos");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Fundo azul claro suave
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10));  // espaço entre painéis

        // --- Painel do formulário e botões ---
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID:"), gbc);

        txtId = new JTextField(10);
        txtId.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtId, gbc);

        // Linha 1 - Nome
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Nome:"), gbc);

        txtNome = new JTextField(20);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtNome, gbc);

        // Linha 2 - Descrição (textarea)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Descrição:"), gbc);

        txtDescricao = new JTextArea(4, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollDesc, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 3 - Data Início
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data/Hora Início (yyyy-MM-dd HH:mm:ss):"), gbc);

        txtDataInicio = new JTextField(20);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtDataInicio, gbc);

        // Linha 4 - Data Fim
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data/Hora Fim (yyyy-MM-dd HH:mm:ss):"), gbc);

        txtDataFim = new JTextField(20);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtDataFim, gbc);

        // Linha 5 - Local
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Local:"), gbc);

        txtLocal = new JTextField(20);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtLocal, gbc);

        // Linha 6 - ID Responsável
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Responsável:"), gbc);

        txtIdResponsavel = new JTextField(10);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdResponsavel, gbc);

        // Linha 7 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // --- Painel da tabela ---
        modelo = new DefaultTableModel(
            new Object[]{"ID", "Nome", "Descrição", "Data Início", "Data Fim", "Local", "ID Responsável"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar largura das colunas para melhor visualização
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);  // ID
        tabela.getColumnModel().getColumn(1).setPreferredWidth(120); // Nome
        tabela.getColumnModel().getColumn(2).setPreferredWidth(220); // Descrição
        tabela.getColumnModel().getColumn(3).setPreferredWidth(140); // Data Início
        tabela.getColumnModel().getColumn(4).setPreferredWidth(140); // Data Fim
        tabela.getColumnModel().getColumn(5).setPreferredWidth(100); // Local
        tabela.getColumnModel().getColumn(6).setPreferredWidth(80);  // ID Responsável

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona painéis ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        // Define largura fixa para o painel do formulário para não invadir a tabela
        painelFormulario.setPreferredSize(new Dimension(420, getHeight()));

        // Eventos dos botões
        btnSalvar.addActionListener(e -> salvarEvento());
        btnEditar.addActionListener(e -> editarEvento());
        btnExcluir.addActionListener(e -> excluirEvento());
        btnLimpar.addActionListener(e -> limparCampos());

        // Clique na tabela para preencher formulário
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtId.setText(modelo.getValueAt(linha, 0).toString());
                    txtNome.setText(modelo.getValueAt(linha, 1).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 2).toString());
                    txtDataInicio.setText(modelo.getValueAt(linha, 3).toString());
                    txtDataFim.setText(modelo.getValueAt(linha, 4).toString());
                    txtLocal.setText(modelo.getValueAt(linha, 5).toString());
                    txtIdResponsavel.setText(modelo.getValueAt(linha, 6) != null ? modelo.getValueAt(linha, 6).toString() : "");
                }
            }
        });
    }

    private void listarEventos() {
        modelo.setRowCount(0);
        List<EventoDTO> lista = eventoDAO.listarEventos();
        for (EventoDTO e : lista) {
            modelo.addRow(new Object[]{
                e.getIdEvento(),
                e.getNome(),
                e.getDescricao(),
                e.getDataInicio(),
                e.getDataFim(),
                e.getLocal(),
                e.getIdResponsavel()
            });
        }
    }

    private void salvarEvento() {
        try {
            EventoDTO evento = new EventoDTO();
            evento.setNome(txtNome.getText());
            evento.setDescricao(txtDescricao.getText());
            evento.setDataInicio(new Timestamp(sdf.parse(txtDataInicio.getText()).getTime()));
            evento.setDataFim(new Timestamp(sdf.parse(txtDataFim.getText()).getTime()));
            evento.setLocal(txtLocal.getText());

            String idRespTxt = txtIdResponsavel.getText().trim();
            if (!idRespTxt.isEmpty()) {
                evento.setIdResponsavel(Integer.parseInt(idRespTxt));
            } else {
                evento.setIdResponsavel(null);
            }

            boolean ok;
            if (txtId.getText().isEmpty()) {
                ok = eventoDAO.inserirEvento(evento);
                if (ok) JOptionPane.showMessageDialog(this, "Evento salvo com sucesso!");
            } else {
                evento.setIdEvento(Integer.parseInt(txtId.getText()));
                ok = eventoDAO.atualizarEvento(evento);
                if (ok) JOptionPane.showMessageDialog(this, "Evento atualizado com sucesso!");
            }
            if (ok) {
                listarEventos();
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar evento.");
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato de data/hora inválido. Use: yyyy-MM-dd HH:mm:ss");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID responsável inválido.");
        }
    }

    private void editarEvento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtId.setText(modelo.getValueAt(linha, 0).toString());
            txtNome.setText(modelo.getValueAt(linha, 1).toString());
            txtDescricao.setText(modelo.getValueAt(linha, 2).toString());
            txtDataInicio.setText(modelo.getValueAt(linha, 3).toString());
            txtDataFim.setText(modelo.getValueAt(linha, 4).toString());
            txtLocal.setText(modelo.getValueAt(linha, 5).toString());
            txtIdResponsavel.setText(modelo.getValueAt(linha, 6) != null ? modelo.getValueAt(linha, 6).toString() : "");
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um evento para editar.");
        }
    }

    private void excluirEvento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int confirmar = JOptionPane.showConfirmDialog(this, "Confirma exclusão do evento?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (confirmar == JOptionPane.YES_OPTION) {
                boolean ok = eventoDAO.excluirEvento(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Evento excluído com sucesso!");
                    listarEventos();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir evento.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um evento para excluir.");
        }
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtDescricao.setText("");
        txtDataInicio.setText("");
        txtDataFim.setText("");
        txtLocal.setText("");
        txtIdResponsavel.setText("");
        tabela.clearSelection();
    }
}
