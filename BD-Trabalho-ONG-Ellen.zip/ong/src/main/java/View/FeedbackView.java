package View;

import DAO.FeedbackDAO;
import DTO.FeedbackDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class FeedbackView extends JFrame {

    private JTextField txtIdFeedback;
    private JTextField txtIdUsuario;
    private JTextArea txtMensagem;
    private JTextField txtDataEnvio;

    private JTable tabela;
    private DefaultTableModel modelo;

    private FeedbackDAO dao;

    public FeedbackView() {
        dao = new FeedbackDAO();
        initComponents();
        listarFeedbacks();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Feedbacks");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        getContentPane().setBackground(new Color(173, 216, 230)); // azul claro
        setLayout(new BorderLayout(10, 10));

        // Painel formulário com GridBagLayout
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID Feedback
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Feedback:"), gbc);

        txtIdFeedback = new JTextField(10);
        txtIdFeedback.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdFeedback, gbc);

        // Linha 1 - ID Usuário
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Usuário:"), gbc);

        txtIdUsuario = new JTextField(10);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdUsuario, gbc);

        // Linha 2 - Mensagem (TextArea)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Mensagem:"), gbc);

        txtMensagem = new JTextArea(6, 25);
        txtMensagem.setLineWrap(true);
        txtMensagem.setWrapStyleWord(true);
        JScrollPane scrollMensagem = new JScrollPane(txtMensagem);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollMensagem, gbc);

        // Linha 3 - Data Envio
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.anchor = GridBagConstraints.WEST;
        painelFormulario.add(new JLabel("Data Envio:"), gbc);

        txtDataEnvio = new JTextField(20);
        txtDataEnvio.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtDataEnvio, gbc);

        // Linha 4 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Tabela
        modelo = new DefaultTableModel(new Object[]{"ID Feedback", "ID Usuário", "Mensagem", "Data Envio"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar largura colunas para melhor visualização
        tabela.getColumnModel().getColumn(0).setPreferredWidth(80);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(80);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(250);
        tabela.getColumnModel().getColumn(3).setPreferredWidth(130);

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adicionar componentes ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        painelFormulario.setPreferredSize(new Dimension(420, getHeight()));

        // Eventos
        btnSalvar.addActionListener(e -> salvarFeedback());
        btnExcluir.addActionListener(e -> excluirFeedback());
        btnLimpar.addActionListener(e -> limparCampos());

        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdFeedback.setText(modelo.getValueAt(linha, 0).toString());
                    txtIdUsuario.setText(modelo.getValueAt(linha, 1).toString());
                    txtMensagem.setText(modelo.getValueAt(linha, 2).toString());
                    txtDataEnvio.setText(modelo.getValueAt(linha, 3).toString());
                }
            }
        });
    }

    private void listarFeedbacks() {
        modelo.setRowCount(0);
        List<FeedbackDTO> lista = dao.listarFeedbacks();
        for (FeedbackDTO fb : lista) {
            modelo.addRow(new Object[]{
                    fb.getIdFeedback(),
                    fb.getIdUsuario(),
                    fb.getMensagem(),
                    fb.getDataEnvio()
            });
        }
    }

    private void salvarFeedback() {
        String idUsuarioStr = txtIdUsuario.getText().trim();
        String mensagem = txtMensagem.getText().trim();

        if (idUsuarioStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o ID do usuário.");
            return;
        }
        if (mensagem.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mensagem não pode ser vazia.");
            return;
        }

        int idUsuario;
        try {
            idUsuario = Integer.parseInt(idUsuarioStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID do usuário inválido.");
            return;
        }

        FeedbackDTO fb = new FeedbackDTO();
        fb.setIdUsuario(idUsuario);
        fb.setMensagem(mensagem);

        boolean ok = dao.inserirFeedback(fb);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Feedback salvo com sucesso!");
            listarFeedbacks();
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar feedback.");
        }
    }

    private void excluirFeedback() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão do feedback?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = dao.excluirFeedback(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Feedback excluído com sucesso!");
                    listarFeedbacks();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir feedback.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um feedback para excluir.");
        }
    }

    private void limparCampos() {
        txtIdFeedback.setText("");
        txtIdUsuario.setText("");
        txtMensagem.setText("");
        txtDataEnvio.setText("");
        tabela.clearSelection();
    }
}
