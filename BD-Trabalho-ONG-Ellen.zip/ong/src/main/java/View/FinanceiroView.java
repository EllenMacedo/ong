package View;

import DAO.FinanceiroDAO;
import DTO.FinanceiroDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class FinanceiroView extends JFrame {

    private JTextField txtIdLancamento;
    private JComboBox<String> cbTipo;
    private JTextField txtValor;
    private JTextArea txtDescricao;
    private JTextField txtData;
    private JTextField txtIdProjeto;

    private JTable tabela;
    private DefaultTableModel modelo;

    private FinanceiroDAO dao;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public FinanceiroView() {
        dao = new FinanceiroDAO();
        initComponents();
        listarLancamentos();
    }

    private void initComponents() {
        setTitle("Gerenciamento Financeiro");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Fundo azul claro suave
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10));

        // Painel do formulário
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID:"), gbc);

        txtIdLancamento = new JTextField(10);
        txtIdLancamento.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdLancamento, gbc);

        // Linha 1 - Tipo
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Tipo:"), gbc);

        cbTipo = new JComboBox<>(new String[]{"entrada", "saida"});
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(cbTipo, gbc);

        // Linha 2 - Valor
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Valor:"), gbc);

        txtValor = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtValor, gbc);

        // Linha 3 - Descrição
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Descrição:"), gbc);

        txtDescricao = new JTextArea(4, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollDesc, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 4 - Data
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data (yyyy-MM-dd):"), gbc);

        txtData = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtData, gbc);

        // Linha 5 - ID Projeto
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Projeto:"), gbc);

        txtIdProjeto = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdProjeto, gbc);

        // Linha 6 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Painel da tabela
        modelo = new DefaultTableModel(
            new Object[]{"ID", "Tipo", "Valor", "Descrição", "Data", "ID Projeto"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar larguras das colunas
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);  // ID
        tabela.getColumnModel().getColumn(1).setPreferredWidth(80);  // Tipo
        tabela.getColumnModel().getColumn(2).setPreferredWidth(70);  // Valor
        tabela.getColumnModel().getColumn(3).setPreferredWidth(180); // Descrição
        tabela.getColumnModel().getColumn(4).setPreferredWidth(90);  // Data
        tabela.getColumnModel().getColumn(5).setPreferredWidth(80);  // ID Projeto

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona painéis ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        // Define tamanho fixo para formulário
        painelFormulario.setPreferredSize(new Dimension(420, getHeight()));

        // Ações dos botões
        btnSalvar.addActionListener(e -> salvarLancamento());
        btnEditar.addActionListener(e -> editarLancamento());
        btnExcluir.addActionListener(e -> excluirLancamento());
        btnLimpar.addActionListener(e -> limparCampos());

        // Preencher formulário ao clicar na tabela
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdLancamento.setText(modelo.getValueAt(linha, 0).toString());
                    cbTipo.setSelectedItem(modelo.getValueAt(linha, 1).toString());
                    txtValor.setText(modelo.getValueAt(linha, 2).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 3).toString());
                    txtData.setText(modelo.getValueAt(linha, 4).toString());
                    txtIdProjeto.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
                }
            }
        });
    }

    private void listarLancamentos() {
        modelo.setRowCount(0);
        List<FinanceiroDTO> lista = dao.listarLancamentos();
        for (FinanceiroDTO f : lista) {
            modelo.addRow(new Object[]{
                f.getIdLancamento(),
                f.getTipo(),
                f.getValor(),
                f.getDescricao(),
                f.getData(),
                f.getIdProjeto()
            });
        }
    }

    private void salvarLancamento() {
        try {
            FinanceiroDTO f = new FinanceiroDTO();
            f.setTipo((String) cbTipo.getSelectedItem());
            f.setValor(new BigDecimal(txtValor.getText().trim()));
            f.setDescricao(txtDescricao.getText());
            java.util.Date parsedDate = sdf.parse(txtData.getText().trim());
            f.setData(new Date(parsedDate.getTime()));

            String idProjetoStr = txtIdProjeto.getText().trim();
            if (!idProjetoStr.isEmpty()) {
                f.setIdProjeto(Integer.parseInt(idProjetoStr));
            } else {
                f.setIdProjeto(null);
            }

            boolean ok;
            if (txtIdLancamento.getText().isEmpty()) {
                ok = dao.inserirLancamento(f);
                if (ok) JOptionPane.showMessageDialog(this, "Lançamento cadastrado com sucesso!");
            } else {
                f.setIdLancamento(Integer.parseInt(txtIdLancamento.getText()));
                ok = dao.atualizarLancamento(f);
                if (ok) JOptionPane.showMessageDialog(this, "Lançamento atualizado com sucesso!");
            }

            if (ok) {
                listarLancamentos();
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar lançamento.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Valor e ID Projeto devem ser numéricos.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato yyyy-MM-dd.");
        }
    }

    private void editarLancamento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtIdLancamento.setText(modelo.getValueAt(linha, 0).toString());
            cbTipo.setSelectedItem(modelo.getValueAt(linha, 1).toString());
            txtValor.setText(modelo.getValueAt(linha, 2).toString());
            txtDescricao.setText(modelo.getValueAt(linha, 3).toString());
            txtData.setText(modelo.getValueAt(linha, 4).toString());
            txtIdProjeto.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um lançamento para editar.");
        }
    }

    private void excluirLancamento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão do lançamento?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = dao.excluirLancamento(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Lançamento excluído com sucesso!");
                    listarLancamentos();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir lançamento.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um lançamento para excluir.");
        }
    }

    private void limparCampos() {
        txtIdLancamento.setText("");
        cbTipo.setSelectedIndex(0);
        txtValor.setText("");
        txtDescricao.setText("");
        txtData.setText("");
        txtIdProjeto.setText("");
        tabela.clearSelection();
    }
}
