package View;

import DAO.UsuarioDAO;
import DTO.UsuarioDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GerenciamentoUsuarioView extends JFrame {

    private JTable tabelaUsuarios;
    private DefaultTableModel modeloTabela;
    private UsuarioDAO usuarioDAO;

    public GerenciamentoUsuarioView() {
        usuarioDAO = new UsuarioDAO();
        setTitle("Gerenciamento de Usuário");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Fundo azul claro
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10)); // gaps entre áreas

        criarComponentes();
        carregarUsuarios();
    }

    private void criarComponentes() {
        // Colunas da tabela
        String[] colunas = {"ID", "Nome", "Email", "Perfil", "Ativo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        tabelaUsuarios = new JTable(modeloTabela);
        tabelaUsuarios.setFillsViewportHeight(true);
        tabelaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tabelaUsuarios);

        // Painel lateral para botões (vertical)
        JPanel painelBotoes = new JPanel();
        painelBotoes.setLayout(new BoxLayout(painelBotoes, BoxLayout.Y_AXIS));
        painelBotoes.setBackground(new Color(173, 216, 230));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnAdicionar = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnAtivarDesativar = new JButton("Ativar / Desativar");
        JButton btnExcluir = new JButton("Excluir");

        // Espaçamento vertical entre botões
        int espacamento = 10;

        // Adiciona botões ao painel com espaçamento
        painelBotoes.add(btnAdicionar);
        painelBotoes.add(Box.createVerticalStrut(espacamento));
        painelBotoes.add(btnEditar);
        painelBotoes.add(Box.createVerticalStrut(espacamento));
        painelBotoes.add(btnAtivarDesativar);
        painelBotoes.add(Box.createVerticalStrut(espacamento));
        painelBotoes.add(btnExcluir);
        painelBotoes.add(Box.createVerticalGlue()); // empurra os botões para o topo

        // Ações dos botões
        btnAdicionar.addActionListener(e -> abrirDialogUsuario(null));
        btnEditar.addActionListener(e -> {
            Integer id = getIdUsuarioSelecionado();
            if (id != null) abrirDialogUsuario(id);
        });
        btnAtivarDesativar.addActionListener(e -> ativarDesativarUsuario());
        btnExcluir.addActionListener(e -> excluirUsuario());

        // Adiciona componentes ao frame
        add(painelBotoes, BorderLayout.WEST);
        add(scroll, BorderLayout.CENTER);
    }

    private void carregarUsuarios() {
        modeloTabela.setRowCount(0);
        List<UsuarioDTO> usuarios = usuarioDAO.listarUsuarios();
        for (UsuarioDTO u : usuarios) {
            modeloTabela.addRow(new Object[]{
                u.getIdUsuario(),
                u.getNome(),
                u.getEmail(),
                u.getPerfil(),
                u.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private Integer getIdUsuarioSelecionado() {
        int linha = tabelaUsuarios.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um usuário na tabela.");
            return null;
        }
        return (Integer) modeloTabela.getValueAt(linha, 0);
    }

    private void abrirDialogUsuario(Integer idUsuario) {
        CadastroUsuarioDialog dialog = new CadastroUsuarioDialog(this, true, idUsuario);
        dialog.setVisible(true);
        carregarUsuarios();
    }

    private void ativarDesativarUsuario() {
        Integer id = getIdUsuarioSelecionado();
        if (id != null) {
            int linha = tabelaUsuarios.getSelectedRow();
            String ativoStr = (String) modeloTabela.getValueAt(linha, 4);
            boolean ativo = ativoStr.equals("Sim");
            boolean sucesso = usuarioDAO.desativarAtivarUsuario(id, !ativo);
            if (sucesso) {
                carregarUsuarios();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao alterar status.");
            }
        }
    }

    private void excluirUsuario() {
        Integer id = getIdUsuarioSelecionado();
        if (id != null) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Deseja realmente excluir este usuário?",
                    "Confirmação",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                boolean sucesso = usuarioDAO.excluirUsuario(id);
                if (sucesso) {
                    carregarUsuarios();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir usuário.");
                }
            }
        }
    }
}
