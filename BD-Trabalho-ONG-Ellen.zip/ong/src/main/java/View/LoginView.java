package View;

import DAO.LoginDAO;
import DTO.LoginDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;

public class LoginView extends JFrame {

    private JTextField txtEmail;
    private JPasswordField txtSenha;
    private JButton btnEntrar;

    public LoginView() {
        // Tela cheia
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Login");

        // Painel principal
        JPanel painelPrincipal = new JPanel(new BorderLayout());
        painelPrincipal.setBackground(new Color(245, 245, 220)); // bege claro

        // Painel lateral verde claro
        JPanel painelLateral = new JPanel();
        painelLateral.setPreferredSize(new Dimension(250, getHeight()));
        painelLateral.setBackground(new Color(144, 238, 144)); // verde claro
        painelLateral.setLayout(new BorderLayout());

        JLabel lblLogo = new JLabel("ONG", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Arial", Font.BOLD, 20));
        lblLogo.setForeground(Color.DARK_GRAY);
        painelLateral.add(lblLogo, BorderLayout.NORTH);

        // Painel de login com cantos arredondados
        JPanel painelLogin = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30));
            }
        };
        painelLogin.setOpaque(false);
        painelLogin.setLayout(null);
        painelLogin.setPreferredSize(new Dimension(400, 300));

        JLabel lblTitulo = new JLabel("Acesso ao Sistema");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBounds(120, 10, 200, 25);
        painelLogin.add(lblTitulo);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(50, 60, 80, 20);
        painelLogin.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(130, 60, 200, 25);
        painelLogin.add(txtEmail);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(50, 100, 80, 20);
        painelLogin.add(lblSenha);

        txtSenha = new JPasswordField();
        txtSenha.setBounds(130, 100, 200, 25);
        painelLogin.add(txtSenha);

        btnEntrar = new JButton("Entrar");
        btnEntrar.setBounds(130, 150, 100, 30);
        painelLogin.add(btnEntrar);

        // Centraliza o painel de login
        JPanel painelCentro = new JPanel(new GridBagLayout());
        painelCentro.setOpaque(false);
        painelCentro.add(painelLogin);

        painelPrincipal.add(painelLateral, BorderLayout.WEST);
        painelPrincipal.add(painelCentro, BorderLayout.CENTER);

        add(painelPrincipal);
        setVisible(true);

        // Ação do botão
        btnEntrar.addActionListener(e -> realizarLogin());
    }

    private void realizarLogin() {
        String email = txtEmail.getText();
        String senha = new String(txtSenha.getPassword());

        LoginDTO login = new LoginDTO();
        login.setEmail(email);
        login.setSenha(senha);

        LoginDAO dao = new LoginDAO();
        ResultSet rs = dao.autenticarUsuario(login);

        try {
            if (rs != null && rs.next()) {
                String nome = rs.getString("nome");
                String perfil = rs.getString("perfil");

                JOptionPane.showMessageDialog(this, "Bem-vindo, " + nome + "!");

                switch (perfil.toLowerCase()) {
                    case "admin":
                        new AdminView().setVisible(true);
                        break;
                    case "voluntario":
                        new VoluntarioView().setVisible(true);
                        break;
                    case "doador":
                        new DoadorView().setVisible(true);
                        break;
                    case "beneficiario":
                        new BeneficiarioView().setVisible(true);
                        break;
                    default:
                        JOptionPane.showMessageDialog(this, "Perfil desconhecido.");
                        return;
                }

                this.dispose(); // fecha a tela de login

            } else {
                JOptionPane.showMessageDialog(this, "Email ou senha inválidos.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }
}
