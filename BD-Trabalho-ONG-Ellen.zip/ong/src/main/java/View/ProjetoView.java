package View;

import DAO.ProjetoDAO;
import DTO.ProjetoDTO;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Date;
import java.util.List;

public class ProjetoView extends JFrame {

    private JTextField txtId, txtNome, txtObjetivo, txtStatus, txtDataInicio, txtDataFim;
    private JTable tabela;
    private DefaultTableModel modelo;
    private ProjetoDAO projetoDAO;

    public ProjetoView() {
        projetoDAO = new ProjetoDAO();
        setTitle("Projetos");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Fundo azul claro

        initComponents();
        listarProjetos();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10)); // Espaçamento entre painéis

        // --- Painel lateral ---
        JPanel painelLateral = new JPanel();
        painelLateral.setBackground(new Color(144, 238, 144)); // Verde claro
        painelLateral.setPreferredSize(new Dimension(220, getHeight()));
        painelLateral.setLayout(new BoxLayout(painelLateral, BoxLayout.Y_AXIS));
        painelLateral.setBorder(new EmptyBorder(20, 10, 20, 10));

        JLabel lblLogo = new JLabel("UFES");
        lblLogo.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblLogo.setForeground(new Color(0, 100, 0));
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblLogo.setBorder(new EmptyBorder(0, 0, 30, 0));
        painelLateral.add(lblLogo);

        // Botões menu
        JButton btnMenuProjetos = criarBotaoMenu("Projetos");
        JButton btnMenuUsuarios = criarBotaoMenu("Usuários");
        JButton btnMenuEventos = criarBotaoMenu("Eventos");
        // Você pode adicionar mais botões conforme necessidade

        painelLateral.add(btnMenuProjetos);
        painelLateral.add(Box.createRigidArea(new Dimension(0, 15)));
        painelLateral.add(btnMenuUsuarios);
        painelLateral.add(Box.createRigidArea(new Dimension(0, 15)));
        painelLateral.add(btnMenuEventos);

        // --- Painel principal ---
        JPanel painelPrincipal = new JPanel();
        painelPrincipal.setBackground(Color.WHITE);
        painelPrincipal.setBorder(new CompoundBorder(
                new EmptyBorder(20, 20, 20, 20),
                new LineBorder(new Color(200, 200, 200), 1, true) // borda arredondada
        ));
        painelPrincipal.setLayout(null);

        // Campos com labels
        int lblWidth = 100, txtWidth = 300, altura = 30, margemEsq = 20;
        int y = 10, espacamento = 45;

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(margemEsq, y, lblWidth, altura);
        painelPrincipal.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(margemEsq + lblWidth, y, 80, altura);
        txtId.setEditable(false);
        painelPrincipal.add(txtId);

        y += espacamento;
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(margemEsq, y, lblWidth, altura);
        painelPrincipal.add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(margemEsq + lblWidth, y, txtWidth, altura);
        painelPrincipal.add(txtNome);

        y += espacamento;
        JLabel lblObjetivo = new JLabel("Objetivo:");
        lblObjetivo.setBounds(margemEsq, y, lblWidth, altura);
        painelPrincipal.add(lblObjetivo);

        txtObjetivo = new JTextField();
        txtObjetivo.setBounds(margemEsq + lblWidth, y, txtWidth, altura);
        painelPrincipal.add(txtObjetivo);

        y += espacamento;
        JLabel lblStatus = new JLabel("Status:");
        lblStatus.setBounds(margemEsq, y, lblWidth, altura);
        painelPrincipal.add(lblStatus);

        txtStatus = new JTextField();
        txtStatus.setBounds(margemEsq + lblWidth, y, 150, altura);
        painelPrincipal.add(txtStatus);

        y += espacamento;
        JLabel lblDataInicio = new JLabel("Data Início:");
        lblDataInicio.setBounds(margemEsq, y, lblWidth, altura);
        painelPrincipal.add(lblDataInicio);

        txtDataInicio = new JTextField();
        txtDataInicio.setBounds(margemEsq + lblWidth, y, 150, altura);
        painelPrincipal.add(txtDataInicio);

        JLabel lblDataFim = new JLabel("Data Fim:");
        lblDataFim.setBounds(margemEsq + lblWidth + 170, y, lblWidth, altura);
        painelPrincipal.add(lblDataFim);

        txtDataFim = new JTextField();
        txtDataFim.setBounds(margemEsq + lblWidth + 230, y, 150, altura);
        painelPrincipal.add(txtDataFim);

        // Botões
        y += espacamento + 10;
        int btnWidth = 110, btnHeight = 35, btnEspaco = 15;
        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(margemEsq, y, btnWidth, btnHeight);
        painelPrincipal.add(btnSalvar);

        JButton btnEditar = new JButton("Editar");
        btnEditar.setBounds(margemEsq + btnWidth + btnEspaco, y, btnWidth, btnHeight);
        painelPrincipal.add(btnEditar);

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(margemEsq + 2 * (btnWidth + btnEspaco), y, btnWidth, btnHeight);
        painelPrincipal.add(btnExcluir);

        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(margemEsq + 3 * (btnWidth + btnEspaco), y, btnWidth, btnHeight);
        painelPrincipal.add(btnLimpar);

        // Tabela
        y += btnHeight + 20;
        modelo = new DefaultTableModel(new Object[]{"ID", "Nome", "Objetivo", "Status", "Data Início", "Data Fim"}, 0);
        tabela = new JTable(modelo);
        tabela.setFillsViewportHeight(true);
        tabela.setRowHeight(25);
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBounds(margemEsq, y, 800, 300);
        painelPrincipal.add(scroll);

        // Adiciona os painéis na JFrame
        add(painelLateral, BorderLayout.WEST);
        add(painelPrincipal, BorderLayout.CENTER);

        // Eventos
        btnSalvar.addActionListener(e -> salvarProjeto());
        btnEditar.addActionListener(e -> editarProjeto());
        btnExcluir.addActionListener(e -> excluirProjeto());
        btnLimpar.addActionListener(e -> limparCampos());

        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtId.setText(modelo.getValueAt(linha, 0).toString());
                    txtNome.setText(modelo.getValueAt(linha, 1).toString());
                    txtObjetivo.setText(modelo.getValueAt(linha, 2).toString());
                    txtStatus.setText(modelo.getValueAt(linha, 3).toString());
                    txtDataInicio.setText(modelo.getValueAt(linha, 4).toString());
                    txtDataFim.setText(modelo.getValueAt(linha, 5).toString());
                }
            }
        });
    }

    private JButton criarBotaoMenu(String texto) {
        JButton btn = new JButton(texto);
        btn.setMaximumSize(new Dimension(180, 40));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(200, 255, 200));
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setForeground(new Color(0, 100, 0));
        return btn;
    }

    private void listarProjetos() {
        modelo.setRowCount(0);
        List<ProjetoDTO> lista = projetoDAO.listarProjetos();
        for (ProjetoDTO p : lista) {
            modelo.addRow(new Object[]{
                p.getIdProjeto(),
                p.getNome(),
                p.getObjetivo(),
                p.getStatus(),
                p.getDataInicio(),
                p.getDataFim()
            });
        }
    }

    private void salvarProjeto() {
        try {
            ProjetoDTO projeto = new ProjetoDTO();
            projeto.setNome(txtNome.getText());
            projeto.setObjetivo(txtObjetivo.getText());
            projeto.setStatus(txtStatus.getText());
            projeto.setDataInicio(Date.valueOf(txtDataInicio.getText()));
            projeto.setDataFim(Date.valueOf(txtDataFim.getText()));

            boolean ok;
            if (txtId.getText().isEmpty()) {
                ok = projetoDAO.inserirProjeto(projeto);
                if (ok) JOptionPane.showMessageDialog(this, "Projeto salvo com sucesso!");
            } else {
                projeto.setIdProjeto(Integer.parseInt(txtId.getText()));
                ok = projetoDAO.atualizarProjeto(projeto);
                if (ok) JOptionPane.showMessageDialog(this, "Projeto atualizado com sucesso!");
            }
            if (ok) {
                listarProjetos();
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar projeto.");
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use formato: aaaa-mm-dd");
        }
    }

    private void editarProjeto() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtId.setText(modelo.getValueAt(linha, 0).toString());
            txtNome.setText(modelo.getValueAt(linha, 1).toString());
            txtObjetivo.setText(modelo.getValueAt(linha, 2).toString());
            txtStatus.setText(modelo.getValueAt(linha, 3).toString());
            txtDataInicio.setText(modelo.getValueAt(linha, 4).toString());
            txtDataFim.setText(modelo.getValueAt(linha, 5).toString());
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um projeto para editar.");
        }
    }

    private void excluirProjeto() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int confirmar = JOptionPane.showConfirmDialog(this, "Confirma exclusão do projeto?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (confirmar == JOptionPane.YES_OPTION) {
                boolean ok = projetoDAO.excluirProjeto(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Projeto excluído com sucesso!");
                    listarProjetos();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir projeto.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um projeto para excluir.");
        }
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtObjetivo.setText("");
        txtStatus.setText("");
        txtDataInicio.setText("");
        txtDataFim.setText("");
        tabela.clearSelection();
    }
}
