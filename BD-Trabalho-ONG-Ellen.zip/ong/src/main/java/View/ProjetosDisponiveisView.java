package View;

import javax.swing.*;

public class ProjetosDisponiveisView extends JFrame {

    public ProjetosDisponiveisView() {
        setTitle("Projetos Disponíveis");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl = new JLabel("Projetos que você pode participar:");
        lbl.setBounds(30, 20, 300, 30);
        add(lbl);

        JTextArea txtProjetos = new JTextArea();
        txtProjetos.setEditable(false);
        txtProjetos.setText("• Projeto de Reforço Escolar\n• Projeto de Apoio Psicológico\n...");
        JScrollPane scroll = new JScrollPane(txtProjetos);
        scroll.setBounds(30, 60, 320, 120);
        add(scroll);

        JButton btnParticipar = new JButton("Quero Participar");
        btnParticipar.setBounds(30, 200, 150, 30);
        add(btnParticipar);

        btnParticipar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Inscrição enviada com sucesso!");
        });
    }
}
