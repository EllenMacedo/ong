package View;

import DAO.RelatorioDAO;
import DTO.RelatorioDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class RelatorioView extends JFrame {

    private JTextField txtIdRelatorio;
    private JTextField txtTitulo;
    private JTextArea txtDescricao;
    private JTextField txtDataCriacao;
    private JTextField txtIdProjeto;
    private JTextField txtIdUsuario;

    private JTable tabela;
    private DefaultTableModel modelo;

    private RelatorioDAO dao;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public RelatorioView() {
        dao = new RelatorioDAO();
        initComponents();
        listarRelatorios();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Relatórios");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        getContentPane().setBackground(new Color(173, 216, 230)); // azul claro
        setLayout(new BorderLayout(10, 10));

        // Painel do formulário com GridBagLayout
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID:"), gbc);

        txtIdRelatorio = new JTextField(10);
        txtIdRelatorio.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdRelatorio, gbc);

        // Linha 1 - Título
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Título:"), gbc);

        txtTitulo = new JTextField(20);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtTitulo, gbc);

        // Linha 2 - Descrição
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Descrição:"), gbc);

        txtDescricao = new JTextArea(4, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollDesc, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 3 - Data Criação
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data Criação:"), gbc);

        txtDataCriacao = new JTextField(20);
        txtDataCriacao.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtDataCriacao, gbc);

        // Linha 4 - ID Projeto
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Projeto:"), gbc);

        txtIdProjeto = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdProjeto, gbc);

        // Linha 5 - ID Usuário
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Usuário:"), gbc);

        txtIdUsuario = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdUsuario, gbc);

        // Linha 6 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{"ID", "Título", "Descrição", "Data Criação", "ID Projeto", "ID Usuário"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajusta larguras colunas
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(120);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(200);
        tabela.getColumnModel().getColumn(3).setPreferredWidth(140);
        tabela.getColumnModel().getColumn(4).setPreferredWidth(70);
        tabela.getColumnModel().getColumn(5).setPreferredWidth(70);

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona painéis ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        painelFormulario.setPreferredSize(new Dimension(440, getHeight()));

        // Eventos botões
        btnSalvar.addActionListener(e -> salvarRelatorio());
        btnEditar.addActionListener(e -> editarRelatorio());
        btnExcluir.addActionListener(e -> excluirRelatorio());
        btnLimpar.addActionListener(e -> limparCampos());

        // Selecionar na tabela preenche campos
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdRelatorio.setText(modelo.getValueAt(linha, 0).toString());
                    txtTitulo.setText(modelo.getValueAt(linha, 1).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 2).toString());
                    txtDataCriacao.setText(modelo.getValueAt(linha, 3).toString());
                    txtIdProjeto.setText(modelo.getValueAt(linha, 4) != null ? modelo.getValueAt(linha, 4).toString() : "");
                    txtIdUsuario.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
                }
            }
        });
    }

    private void listarRelatorios() {
        modelo.setRowCount(0);
        List<RelatorioDTO> lista = dao.listarRelatorios();
        for (RelatorioDTO r : lista) {
            modelo.addRow(new Object[]{
                    r.getIdRelatorio(),
                    r.getTitulo(),
                    r.getDescricao(),
                    r.getDataCriacao(),
                    r.getIdProjeto(),
                    r.getIdUsuario()
            });
        }
    }

    private void salvarRelatorio() {
        String titulo = txtTitulo.getText().trim();
        if (titulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O título é obrigatório.");
            return;
        }

        RelatorioDTO r = new RelatorioDTO();
        r.setTitulo(titulo);
        r.setDescricao(txtDescricao.getText().trim());

        String idProjetoStr = txtIdProjeto.getText().trim();
        if (!idProjetoStr.isEmpty()) {
            try {
                r.setIdProjeto(Integer.parseInt(idProjetoStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID Projeto inválido.");
                return;
            }
        } else {
            r.setIdProjeto(null);
        }

        String idUsuarioStr = txtIdUsuario.getText().trim();
        if (!idUsuarioStr.isEmpty()) {
            try {
                r.setIdUsuario(Integer.parseInt(idUsuarioStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID Usuário inválido.");
                return;
            }
        } else {
            r.setIdUsuario(null);
        }

        boolean ok;
        if (txtIdRelatorio.getText().isEmpty()) {
            ok = dao.inserirRelatorio(r);
            if (ok) JOptionPane.showMessageDialog(this, "Relatório cadastrado com sucesso!");
        } else {
            try {
                r.setIdRelatorio(Integer.parseInt(txtIdRelatorio.getText()));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID Relatório inválido.");
                return;
            }
            ok = dao.atualizarRelatorio(r);
            if (ok) JOptionPane.showMessageDialog(this, "Relatório atualizado com sucesso!");
        }

        if (ok) {
            listarRelatorios();
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar relatório.");
        }
    }

    private void editarRelatorio() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtIdRelatorio.setText(modelo.getValueAt(linha, 0).toString());
            txtTitulo.setText(modelo.getValueAt(linha, 1).toString());
            txtDescricao.setText(modelo.getValueAt(linha, 2).toString());
            txtDataCriacao.setText(modelo.getValueAt(linha, 3).toString());
            txtIdProjeto.setText(modelo.getValueAt(linha, 4) != null ? modelo.getValueAt(linha, 4).toString() : "");
            txtIdUsuario.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um relatório para editar.");
        }
    }

    private void excluirRelatorio() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão do relatório?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = dao.excluirRelatorio(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Relatório excluído com sucesso!");
                    listarRelatorios();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir relatório.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um relatório para excluir.");
        }
    }

    private void limparCampos() {
        txtIdRelatorio.setText("");
        txtTitulo.setText("");
        txtDescricao.setText("");
        txtDataCriacao.setText("");
        txtIdProjeto.setText("");
        txtIdUsuario.setText("");
        tabela.clearSelection();
    }
}
