package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VoluntarioView extends JFrame {

    public VoluntarioView() {
        setTitle("Área do Voluntário");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Tela cheia
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 245, 220)); // Bege claro
        setLayout(new BorderLayout());

        // Painel da barra lateral com BoxLayout vertical para melhor controle
        JPanel barraLateral = new JPanel();
        barraLateral.setBackground(new Color(144, 238, 144)); // Verde claro
        barraLateral.setPreferredSize(new Dimension(200, getHeight()));
        barraLateral.setLayout(new BoxLayout(barraLateral, BoxLayout.Y_AXIS));

        // Criar botões menores
        JButton btnProjetos = new JButton("Ver Projetos");
        JButton btnEventos = new JButton("Ver Eventos");
        JButton btnLogout = new JButton("Logout");

        Dimension tamanhoBotao = new Dimension(180, 30);
        btnProjetos.setMaximumSize(tamanhoBotao);
        btnProjetos.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEventos.setMaximumSize(tamanhoBotao);
        btnEventos.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogout.setMaximumSize(tamanhoBotao);
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Espaçamento entre botões
        barraLateral.add(Box.createVerticalStrut(30)); // Espaço topo
        barraLateral.add(btnProjetos);
        barraLateral.add(Box.createVerticalStrut(15));
        barraLateral.add(btnEventos);
        barraLateral.add(Box.createVerticalGlue()); // empurra logout pra baixo
        barraLateral.add(btnLogout);
        barraLateral.add(Box.createVerticalStrut(20)); // Espaço final

        // Painel central com fundo branco e bordas arredondadas
        JPanel painelCentral = new JPanel();
        painelCentral.setBackground(Color.WHITE);
        painelCentral.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        painelCentral.setLayout(null);
        painelCentral.setPreferredSize(new Dimension(800, 600));

        JLabel lbl = new JLabel("Bem-vindo, Voluntário!");
        lbl.setBounds(250, 50, 300, 30);
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        painelCentral.add(lbl);

        // Painel para centralizar no centro da tela
        JPanel containerCentral = new JPanel(new GridBagLayout());
        containerCentral.setBackground(new Color(245, 245, 220)); // mesmo bege claro
        containerCentral.add(painelCentral);

        // Adiciona os painéis ao frame
        add(barraLateral, BorderLayout.WEST);
        add(containerCentral, BorderLayout.CENTER);

        // Ações
        btnLogout.addActionListener(e -> {
            dispose();
            new EntradaView().setVisible(true);
        });

        btnProjetos.addActionListener(e -> {
            new ProjetoView().setVisible(true);
        });

        btnEventos.addActionListener(e -> {
            new EventoView().setVisible(true);
        });
    }
}
